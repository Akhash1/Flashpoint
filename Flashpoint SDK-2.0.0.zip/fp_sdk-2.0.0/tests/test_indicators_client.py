from typing import Tuple
from unittest import mock
import os, json

from fp_sdk.data.indicators import Attribute, Event
from fp_sdk.apis.indicators import IndicatorsClient
from fp_sdk.scroll_object import ScrollObject
from .stubs.stub_response import StubResponse


class TestIndicatorsClient():
    @classmethod
    def get_file(self, file_path):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        return open(os.path.join(dir_path, './fixtures', file_path)).read()

    @classmethod
    def get_json(cls, json_file):
        json_data = cls.get_file(json_file)
        test_data = json.loads(json_data)
        return test_data
    
    @classmethod
    def setup_class(cls):
        cls.client = IndicatorsClient(jwt='random', base_url='testing')

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_events_with_scroll(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_multiple_events.json'))
        result = self.client.get_events(scroll=True)
        mock_get.assert_called_with(
            'testing/indicators/event',
            scroll=True
        )
        assert isinstance(result, tuple)

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_events_with_scroll_fail(self, mock_get):
        mock_get.return_value = StubResponse({
            "type": "about:blank",
            "title": "Error",
            "detail": "Too many active scroll sessions",
            "status_code": 429}, fake_status=429)
        result_status = self.client.get_events(scroll=True)
        assert result_status['status_code'] == 429
    
    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_events_without_scroll(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_event.json'))
        result = self.client.get_events()
        mock_get.assert_called_with(
            'testing/indicators/event'
        )
        assert isinstance(result[0], Event)
    
    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_attributes_with_scroll(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_multiple_attributes.json'))
        result = self.client.get_attributes(scroll=True)
        mock_get.assert_called_with(
            'testing/indicators/attribute',
            scroll=True
        )
        assert isinstance(result, tuple)

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_attributes_with_scroll_fail(self, mock_get):
        mock_get.return_value = StubResponse({
            "type": "about:blank",
            "title": "Error",
            "detail": "Too many active scroll sessions",
            "status_code": 429}, fake_status=429)
        result_status = self.client.get_events(scroll=True)
        assert result_status['status_code'] == 429

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_attributes_without_scroll(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_attribute.json'))
        result = self.client.get_attributes()
        mock_get.assert_called_with(
            'testing/indicators/attribute'
        )
        assert isinstance(result[0], Attribute)

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_one_event(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_event.json'))
        result = self.client.get_event('testID')
        mock_get.assert_called_with(
            'testing/indicators/event/testID',
            eventID = 'testID'
        )
        assert isinstance(result, Event)
    
    @mock.patch("fp_sdk.client.FPClient._get")
    def test_get_one_attribute(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_attribute.json'))
        result = self.client.get_attribute('testID')
        mock_get.assert_called_with(
            'testing/indicators/attribute/testID',
            attributeID = 'testID'
        )
        assert isinstance(result, Attribute)
