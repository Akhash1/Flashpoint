from unittest import mock

import pytest

from fp_sdk.apis.search import SearchClient
from fp_sdk.apis.indicators import IndicatorsClient
from fp_sdk.scroll_object import (
    ScrollObject,
    SearchScrollObject,
    IndicatorScrollObject)
from fp_sdk.data import FpDataObject
from tests.stubs.stub_data import StubDataObject, TEST_BASETYPES


class TestScrollObject():

    @classmethod
    def setup_class(cls):
        cls.search_client = SearchClient(jwt="fjskl", base_url="test")
        cls.indicator_client = IndicatorsClient(jwt="fsjk", base_url="test")
        cls.SEARCH_EXPECTED_HITS = [{
            "_source": {
                "something": 1,
                "basetypes": TEST_BASETYPES}}]
        cls.SEARCH_API_RESULTS = {
            "_scroll_id": "blah",
            "hits": {
                "hits": cls.SEARCH_EXPECTED_HITS
            }
        }
        cls.SEARCH_EXPECTED_DATA = FpDataObject.from_response(
            cls.search_client,
            [i["_source"] for i in cls.SEARCH_EXPECTED_HITS])

        cls.SEARCH_API_EMPTY_RESULTS = {
            "_scroll_id": "blah",
            "hits": {
                "hits": []
            }
        }

        cls.INDICATORS_EXPECTED_HITS = [{"something": 1}]
        cls.INDICATORS_API_RESULTS = {
            "scroll_id": "blah",
            "results": [{"something": 1}]
        }
        cls.INDICATORS_API_EMPTY_RESULTS = {
            "scroll_id": "blah",
            "results": []
        }

    @mock.patch("fp_sdk.client.FPClient._delete")
    @mock.patch("fp_sdk.client.FPClient._scroll")
    def test_search_scroll_object(self, mock_scroll, mock_delete):
        mock_scroll.return_value = self.SEARCH_API_RESULTS
        scroll = SearchScrollObject(self.search_client, "something")
        results = scroll.__next__()

        assert len(results) == 1
        assert all(isinstance(i, FpDataObject) for i in results)
        assert all(
            i["something"] == j["something"]
            for i, j in zip(results, self.SEARCH_EXPECTED_DATA))

    @mock.patch("fp_sdk.client.FPClient._delete")
    @mock.patch("fp_sdk.client.FPClient._scroll")
    def test_search_stop_iteration_when_done(self, mock_scroll, mock_delete):
        mock_scroll.return_value = self.SEARCH_API_EMPTY_RESULTS
        scroll = SearchScrollObject(self.search_client, "something")
        
        with pytest.raises(StopIteration):
            results = scroll.__next__()
            assert mock_delete.called

    @mock.patch("fp_sdk.client.FPClient._delete")
    @mock.patch("fp_sdk.client.FPClient._scroll")
    def test_search_stop_iteration_when_error(self, mock_scroll, mock_delete):
        mock_scroll.return_value = self.SEARCH_API_EMPTY_RESULTS
        scroll = SearchScrollObject(self.search_client, "something")
        scroll.scroll_id_key = "doesnt exist"
        
        with pytest.raises(StopIteration):
            results = scroll.__next__()
            assert mock_delete.called

    @mock.patch("fp_sdk.client.FPClient._delete")
    @mock.patch("fp_sdk.client.FPClient._scroll")
    @mock.patch("fp_sdk.data.base.FpDataObject.from_response")
    def test_indicators_scroll_object(self, mock_scroll, mock_delete, mock_from_response):
        mock_scroll.return_value = self.INDICATORS_API_RESULTS
        scroll = IndicatorScrollObject(self.search_client, "something")
        results = scroll.__next__()

        assert results == self.INDICATORS_EXPECTED_HITS
