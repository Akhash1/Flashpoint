from unittest import mock
import pytest
import re

from fp_sdk.apis.search import SearchClient
from fp_sdk.scroll_object import SearchScrollObject
from fp_sdk import basetypes as bt
from fp_sdk.data import FpDataObject
from fp_sdk.exceptions import ScrollTimeLimit


class FakeResponse():
    @staticmethod
    def json():
        return {
            "_scroll_id": "something",
            "hits": {"hits": [], "total": 0}
        }


PARAMETERS = [
    ({"q": "somequery"}, {"q": "somequery"}),
    ({"query": "somequery"}, {"query": "somequery"}),
    ({"size": 10}, {"size": 10}),
    ({"skip": 10}, {"skip": 10}),
    ({"limit": 10}, {"limit": 10}),
    ({"sort": ["somesort", "somesort2"]}, {"sort": "somesort,somesort2"}),
    ({"search_after": "something"}, {"search_after": "something"}),
    ({"aggregations": "blah"}, {"aggregations": "blah"}),
    ({"highlight": True}, {"highlight": True}),
    ({"highlight_query": "weeeeee"}, {"highlight_query": "weeeeee"}),
    ({"highlight_size": 10}, {"highlight_size": 10}),
    ({"source": True}, {"source": True}),
    (
        {"source_includes": ["something", "other"]},
        {"source_includes": "something,other"}
    ),
    (
        {"source_excludes": ["not", "this", "thing"]},
        {"source_excludes": "not,this,thing"}
    ),
    ({"traditional_query": True}, {"traditional_query": True}),
    (
        {"fields": ["one thing", "two thing", "three thing"]},
        {"fields": "one thing,two thing,three thing"}
    ),
    ({"default_operator": "OR"}, {"default_operator": "OR"}),
    ({"timeout": "26s"}, {"timeout": "26s"})
]


class TestSearchAPIClient():

    @classmethod
    def setup_class(cls):
        cls.client = SearchClient(jwt="fjaslkf", base_url="test")
        cls.expected_url = "test/all/search"

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_search_client_search_with_basetypes(self, mock_get):
        mock_get.return_value = FakeResponse()
        result = self.client.search(basetypes=bt.CARD_CVV)
        mock_get.assert_called_with(
            self.expected_url,
            query=self.client._get_basetypes(bt.CARD_CVV))

        # check that self and basetypes were removed
        _, kwargs = mock_get.call_args
        assert all([not isinstance(v, SearchClient) for k, v in kwargs.items()])
        assert "basetypes" not in kwargs
        # check that query is formatted with basetypes
        assert re.search(r"basetypes:\([+\w\s]+\)", kwargs["query"])

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_search_client_search_with_query_and_basetypes(self, mock_get):
        mock_get.return_value = FakeResponse()
        result = self.client.search(basetypes=bt.CARD_CVV, query="somequery")
        mock_get.assert_called_with(
            self.expected_url,
            query="{} {}".format(
                self.client._get_basetypes(bt.CARD_CVV),
                "somequery"))
        assert all(isinstance(i, FpDataObject) for i in result)

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_search_client_search_with_q_and_basetypes(self, mock_get):
        mock_get.return_value = FakeResponse()
        result = self.client.search(basetypes=bt.CARD_CVV, q="somequery")
        mock_get.assert_called_with(
            self.expected_url,
            q="{} {}".format(
                self.client._get_basetypes(bt.CARD_CVV),
                "somequery"))
        assert all(isinstance(i, FpDataObject) for i in result)

    @mock.patch("fp_sdk.client.FPClient._get")
    @pytest.mark.parametrize("arg,expected", PARAMETERS)
    def test_search_client_search(self, mock_get, arg, expected):
        mock_get.return_value = FakeResponse()
        result = self.client.search(**arg)
        mock_get.assert_called_with(
            self.expected_url,
            **expected)
        assert all(isinstance(i, FpDataObject) for i in result)

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_search_from_arg(self, mock_get):
        mock_get.return_value = FakeResponse()
        result = self.client.search(query="somequery", from_=100)
        expected = {"query": "somequery", "from": 100}
        mock_get.assert_called_with(
            self.expected_url,
            **expected)
        assert all(isinstance(i, FpDataObject) for i in result)

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_search_scroll(self, mock_get):
        # test scroll arg is handled properly
        mock_get.return_value = FakeResponse()
        result = self.client.search(query="somequery", scroll="1m")
        mock_get.assert_called_with(
            self.expected_url,
            query="somequery",
            scroll="1m")

        assert isinstance(result, tuple)
        assert isinstance(result[0], list)
        assert isinstance(result[1], SearchScrollObject)
        assert all(isinstance(i, FpDataObject) for i in result[0])

    def test_scroll_time_limit_hour(self):
        with pytest.raises(ScrollTimeLimit):
            result = self.client.search(scroll="1h")

    def test_scroll_time_limit_minutes(self):
        with pytest.raises(ScrollTimeLimit):
            result = self.client.search(scroll="20m")

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_count_method_with_no_results(self, mock_get):
        mock_get.return_value = FakeResponse()
        result = self.client.count(query="somequery")
        assert isinstance(result, int)
        assert result == 0

    @mock.patch("fp_sdk.client.FPClient._get")
    @mock.patch("tests.test_search_api_client.FakeResponse.json")
    def test_count_method_with_results(self, mock_json, mock_get):
        mock_get.return_value = FakeResponse()
        mock_json.return_value = {"hits": {"hits": ['x', 'y'], 'total': 2}}
        result = self.client.count(query="somequery")
        assert isinstance(result, int)
        assert result == 2
