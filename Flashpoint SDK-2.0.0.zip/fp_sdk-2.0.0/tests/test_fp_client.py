from pathlib import Path
import os
from unittest import mock
import logging

import pytest
import vcr

from fp_sdk.client import FPClient
from fp_sdk.exceptions import FlashpointException
from tests.stubs.stub_response import StubResponse


FILE_LOCATION = os.path.dirname(Path(__file__).absolute())


class StubClient(FPClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


def get_cassette(name):
    return os.path.join(FILE_LOCATION, "fixtures/vcr_cassettes", name)


@vcr.use_cassette(get_cassette("success_login.yaml"))
def test_success_login():
    fpclient = StubClient(user="foo", password="bar")
    assert fpclient.login() is True


@vcr.use_cassette(get_cassette("2fa_login.yaml"))
def test_wrong_login_raises_exception():
    fpclient = StubClient(user="foo", password="bar")
    with pytest.raises(FlashpointException):
        fpclient.login()


@vcr.use_cassette(get_cassette("wrong_login.yaml"))
def test_wrong_login_raises_exception():
    fpclient = StubClient(user="foo", password="bar")
    with pytest.raises(FlashpointException):
        fpclient.login()


@pytest.mark.parametrize(
    "fn,method,expected",
    [
        ("_get", "GET", {"params": {}}),
        ("_post", "POST", {"params": {}, "data": "", "json": {}}),
        ("_delete", "DELETE", {"json": {}}),
    ],
)
def test_make_request(fn, method, expected):
    url = "test"
    with mock.patch("fp_sdk.client.FPClient._make_request") as mock_request:
        test_client = StubClient(user="foo", password="bar")
        getattr(test_client, fn)(url)

        mock_request.assert_called_with(method, url, **expected)


@pytest.mark.parametrize(
    "method,params,data,json",
    [
        ("GET", {"param": 1}, '{"data": 1}', {"json": 1}),
        ("POST", {"param": 1}, '{"data": 1}', {"json": 1}),
        ("DELETE", {"param": 1}, '{"data": 1}', {"json": 1}),
    ],
)
def test_logs_requests(method, params, data, json, caplog):
    caplog.set_level(logging.DEBUG, logger="test")
    logger = logging.getLogger("test")
    test_client = StubClient(user="foo", password="bar", logger=logger)

    url = "http://test"

    with mock.patch("fp_sdk.client.requests.Session.send") as mock_send:
        mock_send.return_value = StubResponse({"blah": 1})
        test_client._make_request(
            method, url, params=params, data=data, json=json
        )

        log_str = f"{method} {url}"
        assert log_str in caplog.text
        assert str(json) in caplog.text
        assert str(params) in caplog.text
        assert data in caplog.text
