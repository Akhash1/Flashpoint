import json

from fp_sdk.data import Paste


class TestPasteData():
    @classmethod
    def setup_class(cls):
        paste_data = json.load(open("tests/fixtures/example_paste_post.json"))
        cls.paste = Paste(paste_data, None)

    def test_common_properties(self):
        assert self.paste.site_actor == { "test" : "test" }
        assert self.paste.syntax == "text"
        assert self.paste.title == "nZ4444Vm"
        assert self.paste.unique_visits == 0
    