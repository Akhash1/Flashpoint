import json
from unittest.mock import MagicMock

from fp_sdk.data import ForumPost, ForumUser, Site


class TestForumData():

    @classmethod
    def setup_class(cls):
        forum_data = json.load(open("tests/fixtures/example_forum_post.json"))[0]
        cls.fp_client = MagicMock()
        cls.forum_post = ForumPost(forum_data, cls.fp_client)

    def test_forum_data(self):
        assert 'K8IR9AgKVHeJ19eQRDVPig' == self.forum_post.fpid
        assert 'r9WhSlv9VyS0jQZgrGYV3Q' == self.forum_post.thread_id
        assert 'micopiira5' == self.forum_post.site_actor.handle
        assert '45948' == self.forum_post.site_actor.native_id
        assert isinstance(self.forum_post.site_actor, ForumUser)
        assert isinstance(self.forum_post.site, Site)
        assert 'MPGH (MultiPlayer Game Hacking)' == self.forum_post.site.title
