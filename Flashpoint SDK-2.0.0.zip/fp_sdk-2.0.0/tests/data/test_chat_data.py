import json

from fp_sdk.data import ChatDiscord, ChatQq, ChatTelegram, Site


class TestChatData():

    @classmethod
    def setup_class(cls):
        chat_telegram_data = json.load(open("tests/fixtures/chat_telegram_data.json"))
        chat_discord_data = json.load(open("tests/fixtures/chat_discord_data.json"))
        chat_qq_data = json.load(open("tests/fixtures/chat_qq_data.json"))
        cls.telegram = ChatTelegram(chat_telegram_data, None)
        cls.discord = ChatDiscord(chat_discord_data, None)
        cls.qq = ChatQq(chat_qq_data, None)

    def test_common_properties(self):
        assert self.telegram.aliases == ["Scary Terry", "Scary", "Terry"] # SPOOKY
        assert self.telegram.handle == "Scary Terry"
        assert self.telegram.body == "А чего на мегого не чекаешь?"
        assert self.telegram.site.title == "Telegram"

        assert self.discord.aliases == ["Dank Memer#5192", "Dank Memer"]
        assert self.discord.handle == "Dank Memer"
        assert self.discord.body == "try running the command again, but this time actually mention someone to steal from" # YIKES
        assert self.discord.site.title == "Discord"

        assert self.qq.aliases == ["判官幻影"]
        assert self.qq.handle == "判官幻影"
        assert self.qq.body == "[[分享]疯狂攻击网站，这些黑客被“团灭”！]请使用最新版本手机QQ查看" # YIKES
        assert self.qq.site.title == "QQ"
    