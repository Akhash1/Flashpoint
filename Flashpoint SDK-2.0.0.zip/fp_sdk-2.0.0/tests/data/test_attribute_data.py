from unittest import TestCase
from unittest import mock
import os
import json
import pytest
from fp_sdk.data.indicators import Attribute
from fp_sdk.apis.indicators import IndicatorsClient
from ..stubs.stub_response import StubResponse

class TestAttributeData():
    @classmethod
    def get_file(self, file_path):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        return open(os.path.join(dir_path, '../fixtures', file_path)).read()

    @classmethod
    def get_json(cls, json_file):
        json_data = cls.get_file(json_file)
        test_data = json.loads(json_data)
        return test_data
    
    @classmethod
    def setup_class(cls):
        cls.client = IndicatorsClient(jwt='random', base_url='testing')
        cls.attribute_data = Attribute(cls.get_json('example_attribute.json')[0], cls.client)

    def test_sources(self):
        sources = self.attribute_data.sources
        result_sources = {'actor': ['HiddenCobra', 'APT37'], 'region': ['DPRK'], 'report': ['9v_F9fX1Ts-mvhOEzNqBcg']}
        assert sources == result_sources
    
    @mock.patch("fp_sdk.client.FPClient._get")
    def test_report(self, mock_get):
        mock_get.return_value = StubResponse({
            "report" : "random_report"})
        report = self.attribute_data.report
        mock_get.assert_called_with(
            'https://fp.tools/api/v4/reports/9v_F9fX1Ts-mvhOEzNqBcg'
        )
    
    def test_value(self):
        value = self.attribute_data.value
        result_value = '221.208.194.72'
        assert value == result_value
