from unittest import TestCase
from unittest import mock
import os
import json

import pytest

from fp_sdk.data import Event, Attribute, ForumPost, FpDataObject
from fp_sdk.apis.indicators import IndicatorsClient
from fp_sdk.apis.search import SearchClient
from ..stubs.stub_response import StubResponse


class TestFpDataTranslator():
    @classmethod
    def setup_class(cls):
        cls.client = IndicatorsClient(jwt='random', base_url='testing')
        cls.search_client = SearchClient(jwt='random', base_url='testing')
    
    def get_file(self, file_path):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        return open(os.path.join(dir_path, '../fixtures', file_path)).read()

    def get_json(self, json_file):
        json_data = self.get_file(json_file)
        test_data = json.loads(json_data)
        return test_data

    def test_event_translation(self):
        data = self.get_json('example_event.json')
        assert isinstance(FpDataObject.from_response(fp=None, response_data=data)[0], Event)
    
    def test_attribute_translation(self):
        data = self.get_json('example_attribute.json')
        assert isinstance(FpDataObject.from_response(fp=None, response_data=data)[0], Attribute)
    
    def test_forum_translation(self):
        data = self.get_json('example_forum_post.json')
        assert isinstance(FpDataObject.from_response(fp=None, response_data=data)[0], ForumPost)
    
    def test_no_translation(self):
        data = self.get_json('example_no_translation.json')
        assert isinstance(FpDataObject.from_response(fp=None, response_data=data)[0], FpDataObject)
