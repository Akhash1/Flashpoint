import json

from fp_sdk.data import Chan


class TestChanData():
    test_body = {
        "raw": "Test RAW Data",
        "text/plain": "Test TEXT Data",
        "text/html+sanitized": "Test HTML Data"
      }

    @classmethod
    def setup_class(cls):
        chan_data = json.load(open("tests/fixtures/example_chan_comment.json"))
        cls.chan = Chan(chan_data, None)

    def test_common_properties(self):
        assert self.chan.body == self.test_body
        assert self.chan.site.title == "4chan"
        assert self.chan.site.tags == []
        assert self.chan.site.description == "Social Network / imageboard website"
    