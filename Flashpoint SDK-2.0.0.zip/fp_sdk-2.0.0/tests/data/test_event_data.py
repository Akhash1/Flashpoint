from unittest import TestCase
from unittest import mock
import os
import json
import pytest
from fp_sdk.data.indicators import Attribute, Event
from fp_sdk.apis.indicators import IndicatorsClient
from ..stubs.stub_response import StubResponse

class TestEventData():
    @classmethod
    def get_file(self, file_path):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        return open(os.path.join(dir_path, '../fixtures', file_path)).read()

    @classmethod
    def get_json(cls, json_file):
        json_data = cls.get_file(json_file)
        test_data = json.loads(json_data)
        return test_data

    @classmethod
    def setup_class(cls):
        cls.client = IndicatorsClient(jwt='random', base_url='testing')
        cls.event_data = Event(cls.get_json('example_event.json')[0], cls.client)

    def test_sources(self):
        sources = self.event_data.sources
        result_sources = {'source' : ['CryptingService2']}
        assert sources == result_sources

    @mock.patch("fp_sdk.client.FPClient._get")
    def test_attribute(self, mock_get):
        mock_get.return_value = StubResponse(self.get_json('example_attribute.json'))
        attributes = self.event_data.get_all_attributes()
        assert isinstance(attributes, list)
        assert isinstance(attributes[0], Attribute)
        assert len(attributes) == 1
        assert attributes[0].get('fpid') == '4RN4pegHV-6hIshUC_tbdQ'
