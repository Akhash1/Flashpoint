import json

from fp_sdk.data import CardCvv, CardDump


class TestCardData():

    @classmethod
    def setup_class(cls):
        cvv_data = json.load(open("tests/fixtures/cvv_data.json"))
        dump_data = json.load(open("tests/fixtures/dump_data.json"))
        cls.cvv = CardCvv(cvv_data, None)
        cls.dump = CardDump(dump_data, None)

    def test_common_properties(self):
        assert self.cvv.bin == 514161
        assert self.cvv.expiration == "07/19"
        assert self.cvv.card_type == "Mastercard"
        assert self.cvv.payment_method == "test"
        assert self.cvv.level == "test"
        assert self.cvv.bank_name == "test bank LLC"
        assert self.cvv.base_title == "USA_10_04_17"

        assert self.dump.bin == 474481
        assert self.dump.expiration == "01/20"
        assert self.dump.card_type == "Visa"
        assert self.dump.payment_method == "debit"
        assert self.dump.level == "Classic"
        assert self.dump.bank_name == "Bank Of America, N.a."
        assert self.dump.base_title == "PLATFORM (fresh skimmeD) : USA (CO,GA,NV,FL,SC,TX,IL,PA,CA,MI,NC,LA,NJ,MD,other_states + few EU) TR1+TR2/TR2, HIGH VALID 80-85%"

    def test_dump_properties(self):
        assert self.dump.service_code == 201
        assert self.dump.track1 == "123456"
        assert self.dump.track2 == "test"
        assert self.dump.track3 == "teeest"