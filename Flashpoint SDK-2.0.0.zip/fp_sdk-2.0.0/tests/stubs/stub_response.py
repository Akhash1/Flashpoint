class StubResponse():
    def __init__(self, fake_payload, fake_status=200):
        self.payload = fake_payload
        self.status_code = fake_status
  
    def json(self):
        return self.payload
    
    def status_code(self):
        return self.status