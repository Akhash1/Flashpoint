from fp_sdk.data import FpDataObject


TEST_BASETYPES = ["test", "test2"]

class StubDataObject(FpDataObject):
    basetypes = TEST_BASETYPES
