from typing import Type
from abc import ABC, abstractmethod
import logging

import requests

from fp_sdk.exceptions import FailedLogin, FlashpointException


class FPClient(ABC):
    """
    Main class for FP API interaction.

    This class does the login/authentication of users, but most of the logic
    of interaction of different FP APIs is delegated to other classes.

    This class is designed as an abstract base class, and should not be
    instantiated.  Instead, use the subclasses.
    """

    @abstractmethod
    def __init__(
        self,
        jwt: str = None,
        user: str = None,
        password: str = None,
        base_url: str = "https://fp.tools/api/v4",
        logger: Type[logging.Logger] = None,
    ):
        """Constructor method.

        Must receive either a jwt or a combination of user and password.

        Args:
            jwt (str): A string containing the JWT.
            user (str): A string contining a username.
            password (str): A string containing a password.

        Keyword Args:
            base_url (str):  A string containing the base url.  This is used
                             to specify an alternate API url.

        Raises:
            FailedLogin: If the login fails for any reason.
        """
        if not jwt and not (user and password):
            raise FailedLogin(
                "Either an API token or an user and password are required"
            )
        self.jwt = jwt
        self.user = user
        self.password = password

        self._session = requests.Session()
        self.base_url = base_url
        self.login_url = "login-policy/login"

        self._logger = logger

    @property
    def headers(self) -> dict:
        """
        The authorization header needed to authenticate with Flashpoint APIs
        """
        return {"Authorization": "Bearer {}".format(self.jwt)}

    @property
    def is_authenticated(self) -> bool:
        """
        Returns whether or not you have a JWT that authentications with Flashpoint APIs
        """
        return self.jwt is not None

    def log_info(self, message):
        if self._logger:
            self._logger.info(message)

    def log_error(self, message):
        if self._logger:
            self._logger.error(message)

    def log_debug(self, message):
        if self._logger:
            self._logger.debug(message)

    def _build_url(self, endpoint: str) -> str:
        """
        Helper method to build the full API url given a specific endpoint.

        Args:
            endpoint (str): The endpoint to use.

        Returns:
            str: A string containing the full API url.
        """
        return "{}/{}/{}".format(self.base_url, self.api, endpoint)

    def _make_request(
        self,
        method: str,
        url: str,
        data: dict = {},
        json: dict = {},
        params: dict = {},
    ):
        if params.get("source_includes"):
            params.update({"_source_includes": params["source_includes"]})

        if params.get("source_excludes"):
            params.update({"_source_excludes": params["source_excludes"]})

        request = requests.Request(
            method,
            url,
            headers=self.headers,
            data=data,
            json=json,
            params=params,
        )

        request = request.prepare()
        response = self._session.send(request)

        self.log_info(f"{method} {url}")

        headers_to_log = self.headers
        # trim the auth header so credentials arent in logs
        if headers_to_log.get("Authorization"):
            auth_header = headers_to_log["Authorization"][:20]
            trimmed = f"{auth_header}[trimmed]"
            headers_to_log["Authorization"] = trimmed

        debug_msg = f"Headers: {headers_to_log}"
        if params:
            debug_msg = f"{debug_msg} Query: {params}"
        if data:
            debug_msg = f"{debug_msg} Data: {data}"
        if json:
            debug_msg = f"{debug_msg} JSON: {json}"
        self.log_debug(debug_msg)

        if 200 <= response.status_code <= 299:
            return response
        else:
            try:
                detail = response.json()["detail"]
            except Exception:
                # response json could not be decoded
                detail = "An unknown error has occurred."
            detail = f"{detail} ({response.status_code})"
            self.log_error(detail)
            raise FlashpointException(detail)

    def _get(self, url: str, **kwargs) -> requests.Response:
        """Base HTTP get method.

        Subclasses should use this method to get specific endpoints.  URLs
        should be built using :meth:`fp_sdk.FPClient._build_url`, giving it the
        API endpoint. Accepts a set of kwargs corresponding to the various API
        parameters.

        Args:
            url (str): The full API url including base_url, api, and endpoint.

        Returns:
            :class:`requests.Response`: A response object for the request.
        """
        return self._make_request("GET", url, params=kwargs)

    def _post(
        self, url: str, data: str = "", json: dict = {}, params: dict = {}
    ) -> requests.Response:
        """Base HTTP post method.

        Subclasses should use this method to post specific endpoints.  URLs
        should be built using :meth:`fp_sdk.FPClient._build_url`, giving it the
        API endpoint. Accepts a set of kwargs corresponding to the various API
        parameters.

        Args:
            url (str): The full API url including base_url, api, and endpoint.

        Returns:
            :class:`requests.Response`: A response object for the request.
        """
        return self._make_request(
            "POST", url, params=params, json=json, data=data
        )

    def _delete(self, url: str, **kwargs) -> requests.Response:
        """
        Base HTTP post method.

        Subclasses should use this method to delete specific endpoints.  URLs
        should be built using :meth:`fp_sdk.FPClient._build_url`, giving it the
        API endpoint. Accepts a set of kwargs corresponding to the various API
        parameters.

        Args:
            url (str): The full API url including base_url, api, and endpoint.

        Returns:
            :class:`requests.Response`: A response object for the request.
        """
        return self._make_request("DELETE", url, json=kwargs)

    def _scroll(self, scroll_id, scroll_time="", format_type="") -> dict:
        """
        Method that performs scorlling when the scroll parameter in the endpoint is set to True

        Args:
            scroll_id (str): The ID of the scroll that is posted to the scroll endpoint for further data
            scroll_time (str): The amount of time that the scroll is active for
            format_type (str): The format in which you want the data retrieved from the post to scroll

        Returns:
            (dict): A dictionary containing the search results.
        """
        url = self._build_url("scroll")

        data = {"scroll_id": scroll_id}
        params = {}
        if scroll_time:
            params["scroll"] = scroll_time
        if format_type:
            params["format"] = format_type

        response = self._post(url, json=data, params=params)
        results = response.json()
        return results

    def login(self) -> bool:
        """
        Performs a login when user and password were provided at instatiation.

        Returns:
            bool

        Raises:
            FailedLogin: If login fails for any reason.
        """
        data = {"username": self.user, "password": self.password}
        login_url = "{}/{}".format(self.base_url, self.login_url)
        res = self._post(login_url, data=data)

        if res.status_code == 200:
            auth_json = res.json()
            if "bearer" in auth_json:
                self.jwt = auth_json["bearer"]
                return True
            else:
                raise FailedLogin("Unexpected login failure %s" % res.text)
        elif res.status_code == 202 and "2FA" in res.text:
            raise FailedLogin(
                "Account requires MFA.",
                "Provide credentials for an account without MFA or an API token",
                "generated from https://fp.tools/home/integrations/tokens",
            )
        else:
            raise FailedLogin(
                "Failed login. status_code : %s \n %s"
                % (res.status_code, res.text)
            )
