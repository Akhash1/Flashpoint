from abc import ABC, abstractmethod
import signal
import traceback
import sys

from fp_sdk.data import FpDataObject


original_sigint = signal.getsignal(signal.SIGINT)


def sigint_stop_scroll(signum, frame):
    signal.signal(signal.SIGINT, original_sigint)
    raise StopIteration


class ScrollObject(ABC):
    @abstractmethod
    def __init__(self, fp, scroll_id):
        self.fp = fp
        self.scroll_id = scroll_id
        self.scroll_size = 10

    @abstractmethod
    def _extract_results(self, data):
        pass

    def __iter__(self):
        signal.signal(signal.SIGINT, sigint_stop_scroll)
        return self

    def _scroll(self):
        return self.fp._scroll(self.scroll_id)

    def clear_scroll(self):
        self.fp._delete(self.fp._build_url('scroll'), scroll_id=self.scroll_id)
        signal.signal(signal.SIGINT, original_sigint)

    def __next__(self):
        try:
            results = self._scroll()
            hits = self._extract_results(results)

            if results[self.scroll_id_key]:
                self.scroll_id = results[self.scroll_id_key]
            self.scroll_size = len(hits)
        except Exception:
            tb = "\n".join([
                i.strip()
                for i in traceback.format_exception(*sys.exc_info())])
            self.fp.log_error(tb)
            self.clear_scroll()
            raise StopIteration

        if self.scroll_size > 0:
            return hits
        else:
            self.clear_scroll()
            raise StopIteration


class IndicatorScrollObject(ScrollObject):
    def __init__(self, *args, format_type=None):
        super().__init__(*args)
        self.scroll_id_key = "scroll_id"
        self.format_type = format_type

    def _extract_results(self, data):
        return data["results"]

    def _scroll(self):
        data = None
        if self.format_type:
            data = self.fp._scroll(
                self.scroll_id,
                format_type=self.format_type)
        else:
            data = self.fp._scroll(self.scroll_id)
        return FpDataObject.from_response(self.fp, self._extract_results(data))


class SearchScrollObject(ScrollObject):
    def __init__(self, *args, scroll_time=""):
        super().__init__(*args)
        self.scroll_id_key = "_scroll_id"
        self.scroll_time = scroll_time

    def _extract_results(self, data):
        return [i["_source"] for i in data["hits"]["hits"]]

    def _scroll(self):
        return self.fp._scroll(self.scroll_id, scroll_time=self.scroll_time)

    def __next__(self):
        hits = super().__next__()
        return FpDataObject.from_response(self.fp, hits)
