from typing import List, Tuple, Union

from fp_sdk.client import FPClient
from fp_sdk.scroll_object import SearchScrollObject
from fp_sdk.data import FpDataObject
from fp_sdk.exceptions import ScrollTimeLimit


class SearchClient(FPClient):
    '''
    Search API client.
    '''

    def __init__(self, *args, **kwargs):
        """Constructor method.

        Must receive either a jwt or a combination of user and password.

        Args:
            jwt (str): A string containing the JWT.
            user (str): A string contining a username.
            password (str): A string containing a password.

        Keyword Args:
            base_url (str):  A string containing the base url.  This is used
                             to specify an alternate API url.

        Raises:
            FailedLogin: If the login fails for any reason.
        """
        super().__init__(*args, **kwargs)
        self.api = "all"

    def _get_basetypes(self, basetypes: List[str]) -> str:
        return "basetypes:({})".format(
            " ".join("+{}".format(b) for b in basetypes))

    def count(
        self,
        q: str = "",
        query: str = "",
        *args,
        **kwargs
    ):
        """General count method. Return the total hits for a query on our data.

        Keyword Args:
            q (str): Free-text search query using ES URI search described
                here https://www.elastic.co/guide/en/elasticsearch/reference/current/search-uri-request.html#search-uri-request

                Either `query` or `q` parameter is required. If both are
                provided the `query` takes precedence and `q` is ignored.

                Note: `*` or `?` wildcard characters are not allowed as first
                characters in query terms.
            query (str): Free-text search query using the Query DSL described
                here https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl.html

                Either `query` or `q` parameter is required. If both are
                provided the `query` takes precedence and `q` is ignored.

                Note: `*` or `?` wildcard characters are not allowed as first
                characters in query terms.

        Returns:
            (int): the total hits for the query.
        """
        # build params out of all the kwargs that were supplied
        params = {
            k: ",".join(v) if isinstance(v, list) else v
            for k, v in locals().items() if v}
        # we dont want SearchClient object in params
        del params["self"]

        url = self._build_url("search")
        result = self._get(url, **params).json()
        return result["hits"]["total"]

    def search(
        self,
        q: str = "",
        query: str = "",
        basetypes: List[str] = [],
        from_: int = 0,
        size: int = 0,
        skip: int = 0,
        limit: int = 0,
        sort: List[str] = [],
        search_after: str = "",
        aggregations: str = "",
        highlight: bool = False,
        highlight_query: str = "",
        highlight_size: int = 0,
        source: bool = False,
        source_includes: List[str] = [],
        source_excludes: List[str] = [],
        traditional_query: bool = False,
        fields: List[str] = [],
        scroll: str = "",
        default_operator: str = "",
        timeout: str = ""
    ) -> Union[list, Tuple[list, SearchScrollObject]]:
        """General search method.

        This method is used to execute queries against the Flashpoint Search
        API.  It accepts a variety of keyword arguments corresponding to the
        Search API parameters.  It also accepts a basetypes parameter to easily
        run broad queries on specific basetypes.  The SDK also includes a
        :mod:`fp_sdk.basetypes` module with sets of basetypes predefined.

        Keyword Args:
            q (str): Free-text search query using ES URI search described
                here https://www.elastic.co/guide/en/elasticsearch/reference/current/search-uri-request.html#search-uri-request

                Either `query` or `q` parameter is required. If both are
                provided the `query` takes precedence and `q` is ignored.

                Note: `*` or `?` wildcard characters are not allowed as first
                characters in query terms.
            query (str): Free-text search query using the Query DSL described
                here https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl.html

                Either `query` or `q` parameter is required. If both are
                provided the `query` takes precedence and `q` is ignored.

                Note: `*` or `?` wildcard characters are not allowed as first
                characters in query terms.
            basetypes (list): A list of basetype strings.  The module
                :mod:`fp_sdk.basetypes` exists to assist with using basetypes.

                Example:

                ```python
                from fp_sdk import basetypes as bt
                client.search(basetypes=bt.CARD_CVV, limit=10)
                ```
            from_ (int): Defines the offset from the first result object. The
                sum of `from` and `size` parameters cannot exceed 10,000.
            size (int): The maximum number of result objects to return. The sum
                of `from` and `size` parameters cannot exceed 10,000.
            skip (int): Alias for `from`.
            limit (int): Alias for `size`.
            sort (list): A list of field:order pairs to sort the results by.
                Example:
                    sort=["created_at:desc", "author:asc"]
            search_after (string): The identified date of the item to search after.
            aggregations (string): Fields to get aggregations on.
            highlight (bool): Enable highlighting on matched terms in the
                results.
            highlight_query (str): Free form text query to highlight within
                results (but not filter).
            highlight_size (int): The approximate number of characters to
                return in the highlighted element. Set to 0 to return the full
                document. The `highlight` paramater must be `true` for this to
                take affect.
            source (bool): Return _source object from returned hits.
            source_includes (list): A list of fields to include in the _source
                field.

                Example:
                    source_includes=["fpid", "created_at"]
            source_excludes (list): A list of fields to exclude in the _source
                field.

                Example:
                    source_excludes=["body"]
            traditional_query (bool):  Apply traditional logic for interpreting
                boolean operators in the query string. Only affects behavior of
                the `query` parameter; is ignored if `q` is used.

                The input query string is parsed into boolean query tree that
                contains standard `query_string` queries as its building blocks.
            fields (list): A list of fields to search against.  Applies to
                query terms that don't have fields names explicitly set in the
                query string.

                Example:
                    fields=["title", "body.raw"]
            scroll (str): Initiate a scroll session and sets the time-to-live
                of the session.  The scroll API can be used to paginate results
                of large queries.  The value should be an Elasticsearch time
                unit, eg. 1m.  This value cannot exceed 10 minutes.
            default_operator (str): The default operator for the query_string
                URI search query. Applies only when `q` parameter is used. Can
                take either 'AND' or 'OR' values.
            timeout (str): A search timeout, bounding the request to be
                executed within the specified time value and bail with the hits
                accumulated up to that point when expired. Cannot exceed 30
                seconds. Accepts an Elasticsearch time unit, eg. 1m.

        Returns:
            Without scrolling:
                (list): A list of the search results.

            With scrolling:
                (tuple): A tuple containing:
                    (list): The results of the first page.
                    (ScrollObject): A ScrollObject used to iterate over futher
                                    pages.
        """
        # build params out of all the kwargs that were supplied
        params = {
            k: ",".join(v) if isinstance(v, list) else v
            for k, v in locals().items() if v}

        # we dont want SearchClient object in params
        del params["self"]

        # move from_ param to from so it matches API parameter
        if params.get("from_"):
            params.update({"from": params["from_"]})
            del params["from_"]

        # Get scroll and set as variable
        scrl = params.get("scroll")

        # update query string for supplied basetypes
        if params.get("basetypes"):
            basetypes = self._get_basetypes(basetypes)
            # query takes precedence over q, try to update this first
            if params.get("query"):
                params["query"] = "{} {}".format(basetypes, params["query"])
            elif params.get("q"):
                params["q"] = "{} {}".format(basetypes, params["q"])
            # if only basetypes were specified, make it the query string
            else:
                params["query"] = basetypes

            # basetypes isnt an actual api param, remove it here after we used
            # it in the query
            del params["basetypes"]

        if scrl:
            if "h" in scrl:
                raise ScrollTimeLimit("Your scroll is way too long, consider 10m or less")
            if "m" in scrl:
                if int(scrl.replace("m", "")) > 10:
                    raise ScrollTimeLimit("Your scroll is way too long, consider 10m or less")

        url = self._build_url("search")
        results = self._get(url, **params).json()

        hits = [i["_source"] for i in results["hits"]["hits"]]

        if scrl:
            scroll_id = results["_scroll_id"]
            return FpDataObject.from_response(self, hits), SearchScrollObject(
                self, scroll_id, scroll_time=params["scroll"])
        else:
            return FpDataObject.from_response(self, hits)
