from fp_sdk.client import FPClient
from fp_sdk.scroll_object import IndicatorScrollObject
from fp_sdk.data.base import FpDataObject
from typing import Tuple, Union, List


class IndicatorsClient(FPClient):
    '''
    Indicators API Client
    '''

    def __init__(self, *args, **kwargs):
        '''Constructor method.

        Must receive either a jwt or a combination of user and password.

        Args:
            jwt (str): A string containing the JWT.
            user (str): A string contining a username.
            password (str): A string containing a password.

        Keyword Args:
            base_url (str):  A string containing the base url.  This is used
                             to specify an alternate API url.

        Raises:
            FailedLogin: If the login fails for any reason.
        '''

        super().__init__(*args, **kwargs)
        self.api = 'indicators'

    def get_events(
        self,
        skip: int = 0,
        limit: int = 0,
        format: str = '',
        start_date: str = '',
        end_date: str = '',
        updated_since: str = '',
        updated_until: str = '',
        scroll: bool = False,
        search_fields: List[str] = '',
        search_tags: List[str] = '',
        report: str = '',
        query: str = '',
        sort_timestamp: str = '',
        attack_ids: List[str] = ''
    ) -> Union[dict, Tuple[dict, IndicatorScrollObject]]:
        """
        Method to gather events from the indicators API

        This method is used to gather a list of events. Events are groupings of different
        indicators of compromise that contain metadata about the
        situation where these indicators had been observed.

        Keyword Args:
            skip (int): Number of result objects to skip. The sum of the limit and skip parameters cannot exceed 10,000.

            limit (int): The maximum number of result objects to return. The sum of the limit and skip parameters cannot exceed 10,000.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            start_date (str): Only retrieve values created after the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            end_date (str): Only retrieve values created before the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_since (str): Only retrieve values updated or created since the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_until (str): Only retrieve values updated or created until the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            scroll (boolean): Initiates the scrolling of results.
                To initiate scrolling set the scroll parameter to true on either the /event endpoint,
                or the /attribute endpoint. Scrolling can be enabled for both events and attributes.
                To continue scrolling for both events and attributes, do a POST request to the
                /scroll endpoint using the returned scroll_id endpoint.

                Note: Scrolling does not work with the CSV format.

            search_fields (str): Search specific value types. This should be a string of the format a=something,
                b&gt;10 for each comparison. For example, filename==this.exe domain&gt;=something.com

                Note: More information can be found here: https://www.circl.lu/doc/misp/categories-and-types/#types

            search_tags (str): Search for a keyword inside the Tags.
                Can have multiple keywords in a list, such as malware, ransomware.

            report (str): Obtain items related to a specific report, identified by its FPID. For more information about reports,
                read the Reports API documentation.

                Note: Can have multiple keywords in a list, such as A96kuiwySdC3A28zNqDbxA, k7JbZqYbUlSXevyvDoKMdw.

            query (str): A free text search, also accepts the Lucene query syntax.

            sort_timestamp (str): Sort by the timestamp, either ascending or descending

            attack_ids (str): A comma-delimited list of MITRE ATTACK ids to filter events by.

            Returns:
                Without scrolling:
                    (dict): A dictionary containing the search results.

                With scrolling:
                    (tuple): A tuple containing:
                        (dict): The results of the first page.
                        (ScrollObject): A ScrollObject used to iterate over futher
                                        pages.
        """

        params = {
            k: ",".join(v) if isinstance(v, list) else v
            for k, v in locals().items() if v}
        del params['self']

        url = self._build_url('event')
        response = self._get(url, **params)
        results = response.json()
        if params.get('scroll'):
            if response.status_code == 429:
                return results
            scroll_id = results['scroll_id']

            scroll_obj = IndicatorScrollObject(self, scroll_id)
            return FpDataObject.from_response(self, results["results"]), scroll_obj
        return FpDataObject.from_response(self, results)

    def get_event(
        self,
        eventID: int,
        format: str = '',
        download: bool = False
    ) -> dict:
        """
        Method to gather an event from the indicators API

        This method is used to gather a list of events. Events are groupings of different
        indicators of compromise that contain metadata about the
        situation where these indicators had been observed.

        Keyword Args:
            eventID (int): The UUID or FPID that identifies a particular event.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            download (boolean): For queries for individual attributes ,or events, download parameter downloads JSON of record.

                Note: The JSON is not wrapped in a list.

            Returns:
                (dict): A dictionary containing the search results.
        """
        params = {
            k: ",".join(v) if isinstance(v, list) else v
            for k, v in locals().items() if v}
        del params['self']

        url = self._build_url('event/{}'.format(eventID))
        response = self._get(url, **params)
        results = None
        # Using json() will result in an exception since the return value is either CSV or XML
        if format == 'CSV' or format == 'STIX':
            results = response.text
        else:
            results = FpDataObject.from_response(self, response.json())[0]
        return results

    def get_attributes(
        self,
        skip: int = 0,
        limit: int = 0,
        format: str = '',
        start_date: str = '',
        end_date: str = '',
        updated_since: str = '',
        updated_until: str = '',
        scroll: bool = False,
        search_fields: List[str] = '',
        search_tags: List[str] = '',
        report: str = '',
        query: str = '',
        sort_timestamp: str = '',
        attack_ids: List[str] = '',
        types: List[str] = ''
    ) -> Union[dict, Tuple[dict, IndicatorScrollObject]]:
        """
        Method to gather attributes from the indicators API

        This method is used to retrieves a list of indicators of compromise (IOCs) that occur in the context of an event.
        The value of the IOC is inside the value object.

        Keyword Args:
            skip (int): Number of result objects to skip. The sum of the limit and skip parameters cannot exceed 10,000.

            limit (int): The maximum number of result objects to return. The sum of the limit and skip parameters cannot exceed 10,000.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            start_date (str): Only retrieve values created after the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            end_date (str): Only retrieve values created before the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_since (str): Only retrieve values updated or created since the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_until (str): Only retrieve values updated or created until the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            scroll (boolean): Initiates the scrolling of results.
                To initiate scrolling set the scroll parameter to true on either the /event endpoint,
                or the /attribute endpoint. Scrolling can be enabled for both events and attributes.
                To continue scrolling for both events and attributes, do a POST request to the
                /scroll endpoint using the returned scroll_id endpoint.

                Note: Scrolling does not work with the CSV format.

            search_fields (str): Search specific value types. This should be a string of the format a=something,
                b&gt;10 for each comparison. For example, filename==this.exe domain&gt;=something.com

                Note: More information can be found here: https://www.circl.lu/doc/misp/categories-and-types/#types

            search_tags (str): Search for a keyword inside the Tags.
                Can have multiple keywords in a list, such as malware, ransomware.

            report (str): Obtain items related to a specific report, identified by its FPID. For more information about reports,
                read the Reports API documentation.

                Note: Can have multiple keywords in a list, such as A96kuiwySdC3A28zNqDbxA, k7JbZqYbUlSXevyvDoKMdw.

            query (str): A free text search, also accepts the Lucene query syntax.

            sort_timestamp (str): Sort by the timestamp, either ascending or descending

            attack_ids (str): A comma-delimited list of MITRE ATTACK ids to filter events by.

            types (str): Search by Attribute types. Can have multiple terms, e.g. api/v4/indicators/attribute?types=url,domain,ip-src.

            Returns:
                Without scrolling:
                    (dict): A dictionary containing the search results.

                With scrolling:
                    (tuple): A tuple containing:
                        (dict): The results of the first page.
                        (ScrollObject): A ScrollObject used to iterate over futher
                                        pages.
        """
        params = {
            k: ",".join(v) if isinstance(v, list) else v
            for k, v in locals().items() if v}
        del params['self']

        url = self._build_url('attribute')
        response = self._get(url, **params)
        results = response.json()
        if params.get('scroll'):
            if response.status_code == 429:
                return results
            scroll_id = results['scroll_id']

            scroll_obj = IndicatorScrollObject(self, scroll_id, format_type='SIMPLE')
            return FpDataObject.from_response(self, results["results"]), scroll_obj
        return FpDataObject.from_response(self, results)

    def get_attribute(
        self,
        attributeID,
        format: str = '',
        download: bool = False
    ) -> dict:
        """
        Method to gather an attribute from the indicators API

        Keyword Args:
            attributeID (int): The UUID or FPID that identifies a particular attribute.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            download (boolean): For queries for individual attributes ,or events, download parameter downloads JSON of record.

                Note: The JSON is not wrapped in a list.

            Returns:
                (dict): A dictionary containing the search results.
        """
        params = {
            k: ",".join(v) if isinstance(v, list) else v
            for k, v in locals().items() if v}
        del params['self']

        url = self._build_url('attribute/{}'.format(attributeID))
        response = self._get(url, **params)
        results = response.json()
        return FpDataObject.from_response(self, results)[0]

    def get_misp_events(
        self,
        skip: int = 0,
        limit: int = 0,
        start_date: str = '',
        end_date: str = '',
        updated_since: str = '',
        updated_until: str = '',
        scroll: bool = False,
        search_fields: List[str] = '',
        search_tags: List[str] = '',
        report: str = '',
        query: str = '',
        sort_timestamp: str = '',
        attack_ids: List[str] = ''
    ) -> Union[dict, Tuple[dict, IndicatorScrollObject]]:
        """
        Method to gather events from the indicators API in a MISP format
        This method is used to gather a list of events. Events are groupings of different
        indicators of compromise that contain metadata about the
        situation where these indicators had been observed.

        Keyword Args:
            skip (int): Number of result objects to skip. The sum of the limit and skip parameters cannot exceed 10,000.

            limit (int): The maximum number of result objects to return. The sum of the limit and skip parameters cannot exceed 10,000.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            start_date (str): Only retrieve values created after the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            end_date (str): Only retrieve values created before the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_since (str): Only retrieve values updated or created since the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_until (str): Only retrieve values updated or created until the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            scroll (boolean): Initiates the scrolling of results.
                To initiate scrolling set the scroll parameter to true on either the /event endpoint,
                or the /attribute endpoint. Scrolling can be enabled for both events and attributes.
                To continue scrolling for both events and attributes, do a POST request to the
                /scroll endpoint using the returned scroll_id endpoint.

                Note: Scrolling does not work with the CSV format.

            search_fields (str): Search specific value types. This should be a string of the format a=something,
                b&gt;10 for each comparison. For example, filename==this.exe domain&gt;=something.com

                Note: More information can be found here: https://www.circl.lu/doc/misp/categories-and-types/#types

            search_tags (str): Search for a keyword inside the Tags.
                Can have multiple keywords in a list, such as malware, ransomware.

            report (str): Obtain items related to a specific report, identified by its FPID. For more information about reports,
                read the Reports API documentation.

                Note: Can have multiple keywords in a list, such as A96kuiwySdC3A28zNqDbxA, k7JbZqYbUlSXevyvDoKMdw.

            query (str): A free text search, also accepts the Lucene query syntax.

            sort_timestamp (str): Sort by the timestamp, either ascending or descending

            attack_ids (str): A comma-delimited list of MITRE ATTACK ids to filter events by.

            Returns:
                Without scrolling:
                    (dict): A dictionary containing the search results.

                With scrolling:
                    (tuple): A tuple containing:
                        (dict): The results of the first page.
                        (ScrollObject): A ScrollObject used to iterate over futher
                                        pages.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_events(**local_vars, format='MISP')

    def get_csv_events(
        self,
        skip: int = 0,
        limit: int = 0,
        start_date: str = '',
        end_date: str = '',
        updated_since: str = '',
        updated_until: str = '',
        scroll: bool = False,
        search_fields: List[str] = '',
        search_tags: List[str] = '',
        report: str = '',
        query: str = '',
        sort_timestamp: str = '',
        attack_ids: List[str] = ''
    ) -> Union[dict, Tuple[dict, IndicatorScrollObject]]:
        """
        Method to gather events from the indicators API in a CSV format

        This method is used to gather a list of events. Events are groupings of different
        indicators of compromise that contain metadata about the
        situation where these indicators had been observed.

        Keyword Args:
            skip (int): Number of result objects to skip. The sum of the limit and skip parameters cannot exceed 10,000.

            limit (int): The maximum number of result objects to return. The sum of the limit and skip parameters cannot exceed 10,000.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            start_date (str): Only retrieve values created after the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            end_date (str): Only retrieve values created before the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_since (str): Only retrieve values updated or created since the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_until (str): Only retrieve values updated or created until the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            scroll (boolean): Initiates the scrolling of results.
                To initiate scrolling set the scroll parameter to true on either the /event endpoint,
                or the /attribute endpoint. Scrolling can be enabled for both events and attributes.
                To continue scrolling for both events and attributes, do a POST request to the
                /scroll endpoint using the returned scroll_id endpoint.

                Note: Scrolling does not work with the CSV format.

            search_fields (str): Search specific value types. This should be a string of the format a=something,
                b&gt;10 for each comparison. For example, filename==this.exe domain&gt;=something.com

                Note: More information can be found here: https://www.circl.lu/doc/misp/categories-and-types/#types

            search_tags (str): Search for a keyword inside the Tags.
                Can have multiple keywords in a list, such as malware, ransomware.

            report (str): Obtain items related to a specific report, identified by its FPID. For more information about reports,
                read the Reports API documentation.

                Note: Can have multiple keywords in a list, such as A96kuiwySdC3A28zNqDbxA, k7JbZqYbUlSXevyvDoKMdw.

            query (str): A free text search, also accepts the Lucene query syntax.

            sort_timestamp (str): Sort by the timestamp, either ascending or descending

            attack_ids (str): A comma-delimited list of MITRE ATTACK ids to filter events by.

            Returns:
                Without scrolling:
                    (dict): A dictionary containing the search results.

                With scrolling:
                    (tuple): A tuple containing:
                        (dict): The results of the first page.
                        (ScrollObject): A ScrollObject used to iterate over futher
                                        pages.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_events(**local_vars, format='CSV')

    def get_stix_events(
        self,
        skip: int = 0,
        limit: int = 0,
        start_date: str = '',
        end_date: str = '',
        updated_since: str = '',
        updated_until: str = '',
        scroll: bool = False,
        search_fields: List[str] = '',
        search_tags: List[str] = '',
        report: str = '',
        query: str = '',
        sort_timestamp: str = '',
        attack_ids: List[str] = ''
    ) -> Union[dict, Tuple[dict, IndicatorScrollObject]]:
        """
        Method to gather events in the STIX format from the indicators API

        This method is used to gather a list of events. Events are groupings of different
        indicators of compromise that contain metadata about the
        situation where these indicators had been observed.

        Keyword Args:
            skip (int): Number of result objects to skip. The sum of the limit and skip parameters cannot exceed 10,000.

            limit (int): The maximum number of result objects to return. The sum of the limit and skip parameters cannot exceed 10,000.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            start_date (str): Only retrieve values created after the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            end_date (str): Only retrieve values created before the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_since (str): Only retrieve values updated or created since the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_until (str): Only retrieve values updated or created until the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            scroll (boolean): Initiates the scrolling of results.
                To initiate scrolling set the scroll parameter to true on either the /event endpoint,
                or the /attribute endpoint. Scrolling can be enabled for both events and attributes.
                To continue scrolling for both events and attributes, do a POST request to the
                /scroll endpoint using the returned scroll_id endpoint.

                Note: Scrolling does not work with the CSV format.

            search_fields (str): Search specific value types. This should be a string of the format a=something,
                b&gt;10 for each comparison. For example, filename==this.exe domain&gt;=something.com

                Note: More information can be found here: https://www.circl.lu/doc/misp/categories-and-types/#types

            search_tags (str): Search for a keyword inside the Tags.
                Can have multiple keywords in a list, such as malware, ransomware.

            report (str): Obtain items related to a specific report, identified by its FPID. For more information about reports,
                read the Reports API documentation.

                Note: Can have multiple keywords in a list, such as A96kuiwySdC3A28zNqDbxA, k7JbZqYbUlSXevyvDoKMdw.

            query (str): A free text search, also accepts the Lucene query syntax.

            sort_timestamp (str): Sort by the timestamp, either ascending or descending

            attack_ids (str): A comma-delimited list of MITRE ATTACK ids to filter events by.

            Returns:
                Without scrolling:
                    (dict): A dictionary containing the search results.

                With scrolling:
                    (tuple): A tuple containing:
                        (dict): The results of the first page.
                        (ScrollObject): A ScrollObject used to iterate over futher
                                        pages.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_events(**local_vars, format='STIX')

    def get_stix_event(
        self,
        eventID,
        download: bool = False
    ) -> dict:
        """
        Method to gather an event in the STIX format from the indicators API

        Keyword Args:
            eventID (int): The UUID or FPID that identifies a particular event.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            download (boolean): For queries for individual attributes ,or events, download parameter downloads JSON of record.

                Note: The JSON is not wrapped in a list.

            Returns:
                (dict): A dictionary containing the search results.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_event(**local_vars, format='STIX')

    def get_csv_event(
        self,
        eventID,
        download: bool = False
    ) -> dict:
        """
        Method to gather an event in a CSV format from the indicators API

        Keyword Args:
            eventID (int): The UUID or FPID that identifies a particular event.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            download (boolean): For queries for individual attributes ,or events, download parameter downloads JSON of record.

                Note: The JSON is not wrapped in a list.

            Returns:
                (dict): A dictionary containing the search results.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_event(**local_vars, format='CSV')

    def get_misp_event(
        self,
        eventID,
        download: bool = False
    ) -> dict:
        """
        Method to gather an event in the MISP format from the indicators API

        Keyword Args:
            eventID (int): The UUID or FPID that identifies a particular event.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            download (boolean): For queries for individual attributes ,or events, download parameter downloads JSON of record.

                Note: The JSON is not wrapped in a list.

            Returns:
                (dict): A dictionary containing the search results.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_event(**local_vars, format='MISP')

    def get_simple_attributes(
        self,
        skip: int = 0,
        limit: int = 0,
        start_date: str = '',
        end_date: str = '',
        updated_since: str = '',
        updated_until: str = '',
        scroll: bool = False,
        search_fields: List[str] = '',
        search_tags: List[str] = '',
        report: str = '',
        query: str = '',
        sort_timestamp: str = '',
        attack_ids: List[str] = '',
        types: List[str] = ''
    ) -> Union[dict, Tuple[dict, IndicatorScrollObject]]:
        """
        Method to gather simplified attributes from the indicators API

        This method is used to retrieves a list of indicators of compromise (IOCs) that occur in the context of an event.
        The value of the IOC is inside the value object.

        Keyword Args:
            skip (int): Number of result objects to skip. The sum of the limit and skip parameters cannot exceed 10,000.

            limit (int): The maximum number of result objects to return. The sum of the limit and skip parameters cannot exceed 10,000.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            start_date (str): Only retrieve values created after the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            end_date (str): Only retrieve values created before the specified date.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_since (str): Only retrieve values updated or created since the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            updated_until (str): Only retrieve values updated or created until the date inputed.

                Note: Date format is in UTC and follows ISO_8601 or relative values (eg. 30s, 5m, 2h, 3d, 2w, 3M, 2y).

            scroll (boolean): Initiates the scrolling of results.
                To initiate scrolling set the scroll parameter to true on either the /event endpoint,
                or the /attribute endpoint. Scrolling can be enabled for both events and attributes.
                To continue scrolling for both events and attributes, do a POST request to the
                /scroll endpoint using the returned scroll_id endpoint.

                Note: Scrolling does not work with the CSV format.

            search_fields (str): Search specific value types. This should be a string of the format a=something,
                b&gt;10 for each comparison. For example, filename==this.exe domain&gt;=something.com

                Note: More information can be found here: https://www.circl.lu/doc/misp/categories-and-types/#types

            search_tags (str): Search for a keyword inside the Tags.
                Can have multiple keywords in a list, such as malware, ransomware.

            report (str): Obtain items related to a specific report, identified by its FPID. For more information about reports,
                read the Reports API documentation.

                Note: Can have multiple keywords in a list, such as A96kuiwySdC3A28zNqDbxA, k7JbZqYbUlSXevyvDoKMdw.

            query (str): A free text search, also accepts the Lucene query syntax.

            sort_timestamp (str): Sort by the timestamp, either ascending or descending

            attack_ids (str): A comma-delimited list of MITRE ATTACK ids to filter events by.

            types (str): Search by Attribute types. Can have multiple terms, e.g. api/v4/indicators/attribute?types=url,domain,ip-src.

            Returns:
                Without scrolling:
                    (dict): A dictionary containing the search results.

                With scrolling:
                    (tuple): A tuple containing:
                        (dict): The results of the first page.
                        (ScrollObject): A ScrollObject used to iterate over futher
                                        pages.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_attributes(**local_vars, format='SIMPLE')

    def get_simple_attribute(
        self,
        attributeID,
        download: bool = False
    ) -> dict:
        """
        Method to gather a simplified attribute from the indicators API

        Keyword Args:
            attributeID (int): The UUID or FPID that identifies a particular attribute.

            format (str): The format that is supposed to be displayed. Accepted values are FP, MISP, or CSV.

                Note: Attribute endpoint currently only accepts FP format.

            download (boolean): For queries for individual attributes ,or events, download parameter downloads JSON of record.

                Note: The JSON is not wrapped in a list.

            Returns:
                (dict): A dictionary containing the search results.
        """
        local_vars = locals()
        del local_vars['self']
        return self.get_attribute(**local_vars, format='SIMPLE')
