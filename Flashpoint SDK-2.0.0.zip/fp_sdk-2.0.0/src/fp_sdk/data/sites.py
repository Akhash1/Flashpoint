from fp_sdk.data.base import FpDataObject
from fp_sdk import basetypes as bt


class Site(FpDataObject):
    '''
    Data class for a site
    '''
    basetypes = bt.SITE

    @property
    def description(self):
        '''
        the site description
        '''
        return self.get('description', {}).get('raw')

    @property
    def title(self):
        '''
        the site title
        '''
        return self.get('title')

    @property
    def tags(self):
        '''
        tags associated with the site
        '''
        return [i['name'] for i in self.get('tags', [])]
