from typing import Type, Union

from fp_sdk.client import FPClient


class FpDataObject():
    '''
    Base data class

    Other data classes should inherit this class.  This class should not be
    instantiated directly.  To make a data object, use a specific subclass
    or use the `from_response` or `from_basetypes` class methods.
    '''
    basetypes_map = None

    def __init__(self, data: dict, client: Type[FPClient]):
        self.client = client
        self.data = data

    def __getitem__(self, key: str) -> Union[list, dict, str, int, bool]:
        return self.data[key]

    def get(self, key: str, default=None) -> Union[list, dict, str, int, bool]:
        if key in self.data:
            return self.data[key]
        else:
            return default

    @property
    def json(self) -> dict:
        return self.data

    def keys(self):
        return self.data.keys()

    def items(self):
        return self.data.items()

    def __iter__(self):
        return iter(self.data)

    @property
    def last_observed_at_str(self) -> str:
        '''
        String representation of the last observed at time.
        '''
        return self.get("last_observed_at", {}).get("date-time")

    @property
    def last_observed_at(self) -> int:
        '''
        Integer representation of the last observed at time.
        '''
        return int(self.get("last_observed_at", {}).get("timestamp", 0))

    @property
    def fpid(self) -> str:
        '''
        Unique FP identifier
        '''
        return self.get("fpid", "")

    def __repr__(self):
        class_name = type(self).__name__
        return f"<{class_name} - FPID {self.fpid}>"

    @classmethod
    def from_response(
        cls,
        fp: Type[FPClient],
        response_data: list
    ) -> list:
        return [
            cls.from_basetypes(fp, d["basetypes"], d)
            for d in response_data
        ]

    @classmethod
    def from_basetypes(
        cls,
        fp: Type[FPClient],
        basetypes: list,
        data: dict
    ):
        if not cls.basetypes_map:
            cls.basetypes_map = {
                frozenset(c.basetypes): c
                for c in cls.__subclasses__()
            }
        # return sub-instance if basetype is registered, or defaults to FpDataObject
        return cls.basetypes_map.get(frozenset(basetypes), cls)(data, fp)
