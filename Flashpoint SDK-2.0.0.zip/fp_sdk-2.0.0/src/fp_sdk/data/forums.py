from fp_sdk.data.base import FpDataObject
from fp_sdk.data.sites import Site
from fp_sdk.exceptions import IncompleteData
from fp_sdk import basetypes as bt


class ForumUser(FpDataObject):
    '''
    Data class for a site actor in the context of a forum
    '''
    basetypes = bt.FORUM_USER

    @property
    def handle(self):
        '''
        The handle that the site actor uses in the forum
        '''
        return self.get('names', {}).get('handle', '')

    @property
    def native_id(self):
        '''
        The id of the user in the forum
        '''
        return self.get('native_id')


class ForumPost(FpDataObject):
    '''
    Data class for Forum Post
    '''
    basetypes = bt.FORUM_POST

    @property
    def body(self):
        '''
        The body content of the post
        '''
        return self.get('body', {})

    @property
    def text(self):
        '''
        The extracted text from the post
        '''
        return self.body.get('text/plain', '')

    @property
    def created_at(self):
        '''
        The date it was created at
        '''
        return self.get('created_at')

    @property
    def site(self):
        '''
        Returns a site object for the relevant site
        '''
        return Site(self.get("site", {}), self.client)

    @property
    def site_actor(self):
        '''
        Returns a ForumUser with the relevant site-actor information
        '''
        return ForumUser(self.get('site_actor', {}), self.client)

    @property
    def thread_id(self):
        '''
        Returns the thread ID of this post
        '''
        try:
            return self.get("container", {})["fpid"]
        except KeyError:
            raise IncompleteData("post %s missing thread" % self)

    def get_posts_from_thread(self, limit=100):
        '''
        Queries the search API for other posts from the same thread.
        Args:
            limit (int): The maximum number of result objects to return.
        '''
        query = f'+container.fpid:"{self.thread_id}"'
        return self.client.search(basetypes=self.basetypes,
                                  limit=limit,
                                  q=query,
                                  sort='created_at.date-time')
