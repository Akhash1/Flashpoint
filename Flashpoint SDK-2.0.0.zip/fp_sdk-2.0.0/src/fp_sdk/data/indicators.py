from fp_sdk.data.base import FpDataObject
from fp_sdk import basetypes as bt


class IndicatorsCommon():
    '''
    Class to hold properties for both Attribute and Event objects
    '''
    @property
    def sources(self):
        '''
        Sources listed under the tags which classify the Event or Attribute
        '''
        event = self.get('Event')
        tags = event.get('Tag')
        if tags:
            sources = {}
            for tag in tags:
                tag_name = tag['name']
                if ":" in tag_name:
                    source_description = tag_name.split(":")[-1]
                    source_name = tag_name.split(":")[0]
                    if sources.get(source_name):
                        sources[source_name].append(source_description)
                    else:
                        sources[source_name] = [source_description]
            return sources
        else:
            return None


class Attribute(FpDataObject, IndicatorsCommon):
    basetypes = bt.INDICATOR

    @property
    def report(self):
        '''
        The flashpoint report linked to the specific attribute that is being used, performs HTTP requests to the /report endpoint
        '''
        event = self.get('Event')
        report = event.get('report')
        if report:
            url = 'https://fp.tools/api/v4/reports/{}'.format(report.split('/')[-1])
            response = self.client._get(url)
            return response.json()
        else:
            return None

    @property
    def value(self):
        '''
        Represents the payload of an attribute, and is dependent on the type of attribue
        '''
        return self.get('value')[self.get('type')]

    @property
    def event(self):
        '''
        The event that is parenting this specific Attribute
        '''
        event = self.get('Event')
        event_fpid = event.get('fpid')
        return self.client.get_event(eventID=event_fpid)


class Event(FpDataObject, IndicatorsCommon):
    basetypes = bt.MISP_EVENT

    def get_all_attributes(self):
        '''
        Function that performs HTTP calls to retrieve extended information of all Attributes that are children to this Event
        '''
        event = self.get('Event')
        attributes = event.get('Attribute')
        attribute_data_list = []
        for attribute in attributes:
            attribute_endpoint = attribute.get('href')
            attribute_json = self.client._get(attribute_endpoint).json()
            if attribute_json:
                attribute_data_list.append(Attribute(attribute_json[0], self.client))
        return attribute_data_list

    @property
    def attributes(self):
        '''
        All of the attributes linked to this specific Event
        '''
        return self["Event"]["Attribute"]
