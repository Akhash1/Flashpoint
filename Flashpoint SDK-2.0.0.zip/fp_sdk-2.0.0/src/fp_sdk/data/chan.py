from fp_sdk.data.base import FpDataObject
from fp_sdk.data.sites import Site
from fp_sdk import basetypes as bt


class Chan(FpDataObject):
    '''
    Data class for a chan comment
    '''
    basetypes = bt.CHAN_COMMENT

    @property
    def body(self):
        '''
        the chat body
        '''
        return self.get('body', {})

    @property
    def site(self):
        '''
        information related to the site
        '''
        return Site(self.data.get('site'), self.client)
