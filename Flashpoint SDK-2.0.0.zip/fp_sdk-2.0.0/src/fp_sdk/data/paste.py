from fp_sdk.data.base import FpDataObject
from fp_sdk.data.sites import Site
from fp_sdk import basetypes as bt


class Paste(FpDataObject):
    '''
    Data class for a paste comment
    '''
    basetypes = bt.PASTE_POST

    @property
    def site_actor(self):
        '''
        the paste site actor
        '''
        return self.get('site_actor', {})

    @property
    def syntax(self):
        '''
        the paste site actor
        '''
        return self.get('syntax', '')

    @property
    def title(self):
        '''
        the paste site actor
        '''
        return self.get('title', '')

    @property
    def unique_visits(self):
        '''
        the paste site actor
        '''
        return self.get('unique_visits', 0)

    @property
    def site(self):
        '''
        information related to the site
        '''
        return Site(self.data.get('site'), self.client)
