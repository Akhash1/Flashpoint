from fp_sdk.data.base import FpDataObject
from fp_sdk import basetypes as bt
from fp_sdk.data.sites import Site


class ChatCommon():
    basetypes = bt.CHAT_MESSAGE

    '''
    Base data class for a Chat Objects
    '''
    @property
    def aliases(self) -> str:
        '''
        The different aliases of the threat actor
        '''
        names = self.get('site_actor').get('names')
        return names.get('aliases')

    @property
    def handle(self) -> str:
        '''
        The handle used for the threat actor in this instance
        '''
        names = self.get('site_actor').get('names')
        return names.get('handle')

    @property
    def body(self) -> str:
        '''
        The message body that the threat actor sent
        '''
        body = self.get('body')
        if body:  # Sometimes there is no message attached
            return body.get('text/plain')

    @property
    def site(self) -> Site:
        '''
        Details about the site the threat actor is currently on
        '''
        return Site(self.get('site'), self.client)


class ChatQq(FpDataObject, ChatCommon):
    '''
    Data class for a Chat QQ Object
    '''
    basetypes = bt.QQ_MESSAGE


class ChatTelegram(FpDataObject, ChatCommon):
    '''
    Data class for a Chat QQ Object
    '''
    basetypes = bt.TELEGRAM_MESSAGE


class ChatDiscord(FpDataObject, ChatCommon):
    '''
    Data class for a Chat QQ Object
    '''
    basetypes = bt.DISCORD_MESSAGE
