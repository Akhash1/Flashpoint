from fp_sdk.data.base import FpDataObject
from fp_sdk import basetypes as bt


class CardCommon():
    '''
    Class to hold properties for both CVV and Dumps
    '''

    @property
    def bin(self) -> str:
        '''
        The bin for the CVV or dump.
        '''
        return self.get("bin")

    @property
    def expiration(self) -> str:
        '''
        The expiration date for the CVV or dump.
        '''
        return self.get("expiration")

    @property
    def card_type(self) -> str:
        '''
        The card type for the CVV or dump.
        '''
        return self.get("card_type")

    @property
    def payment_method(self) -> str:
        '''
        The payment method for the CVV or dump.
        '''
        return self.get("payment_method")

    @property
    def level(self) -> str:
        '''
        The card level for the CVV or dump.
        '''
        return self.get("level")

    @property
    def bank_name(self) -> str:
        '''
        The bank name for the CVV or dump.
        '''
        return self.get("bank_name")

    @property
    def base_title(self) -> str:
        '''
        The title of the base the card was released in.
        '''
        return self.get("base", {}).get("title")


class CardCvv(FpDataObject, CardCommon):
    '''
    Data class for CVV data.
    '''
    basetypes = bt.CARD_CVV


class CardDump(FpDataObject, CardCommon):
    '''
    Data class for dump data.
    '''
    basetypes = bt.CARD_DUMP

    @property
    def service_code(self) -> str:
        '''
        The service code for the dump.
        '''
        return self.get("service_code")

    @property
    def track1(self) -> str:
        '''
        Track 1 information.
        '''
        return self.get("track1")

    @property
    def track2(self) -> str:
        '''
        Track 2 information.
        '''
        return self.get("track2")

    @property
    def track3(self) -> str:
        '''
        Track 3 information.
        '''
        return self.get("track3")
