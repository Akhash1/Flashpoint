class FailedLogin(Exception):
    pass


class IncompleteData(Exception):
    pass


class FlashpointException(Exception):
    pass


class ScrollTimeLimit(Exception):
    pass
