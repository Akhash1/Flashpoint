'''
Module containing all FP basetypes and data translator
'''

# sites
SITE = ["site"]

# cves
CVE = ["cve", "vulnerability"]
CVE_ADVISORY = ["cve", "advisory"]
CVE_EXPLOIT = ["cve", "exploit"]

# indicators
MISP_EVENT = ["indicator", "misp"]
INDICATOR = ["indicator", "indicator_attribute"]

# markets
GENERIC_MARKET_PRODUCT = ["market", "product", "generic-product"]

# accounts
ACCOUNT = ["market", "product", "account"]
BANK_ACCOUNT = ["market", "product", "account", "bank"]
EBAY_ACCOUNT = ["market", "product", "account", "ebay"]
PAYPAL_ACCOUNT = ["market", "product", "account", "paypal"]

# cards
CARD_CVV = ["market", "product", "card", "cvv"]
CARD_DUMP = ["market", "product", "card", "dump"]

# blogs
BLOG_POST = ["web", "article", "blog", "post"]
BLOG_COMMENT = ["web", "article", "blog", "conversation", "message", "comment"]

# pastes
PASTE_POST = ["paste", "post"]

# chans
CHAN_COMMENT = ["web", "conversation", "chan", "message", "comment"]

# telegram
TELEGRAM_CHANNEL = ["conversation", "chat", "telegram", "container"]
TELEGRAM_MESSAGE = ["conversation", "chat", "telegram", "message"]
TELEGRAM_USER = ["conversation", "chat", "telegram", "site_actor"]
TELEGRAM_MEDIA = ["conversation", "chat", "telegram", "media"]

# QQ
QQ_MESSAGE = ["conversation", "chat", "qq", "message"]

# discord
DISCORD_MESSAGE = ["conversation", "chat", "discord", "message"]

# forums
FORUM_ROOM = ["conversation", "web", "forum", "container", "room"]
FORUM_THREAD = ["conversation", "web", "forum", "container", "thread"]
FORUM_POST = ["conversation", "web", "forum", "message", "post"]
FORUM_USER = ["conversation", "web", "forum", "site_actor", "user"]
FORUM_AGGREGATION = ["conversation", "web", "forum", "container", "site", "aggregation"]
THREAD_AGGREGATION = ["conversation", "web", "forum", "container", "thread", "aggregation"]

# gab
GAB_POST = ["conversation", "web", "gab", "post"]


# common chat type
CHAT_MESSAGE = ['conversation', 'chat']
