0.0.1: Authentication and FPClient class
