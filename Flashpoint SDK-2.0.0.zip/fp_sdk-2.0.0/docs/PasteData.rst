========================
Paste Data Documentation
========================


Paste Data
==========

.. autoclass:: fp_sdk.data.paste.Paste
    :members:
