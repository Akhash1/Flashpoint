===========================
Base FPClient Documentation
===========================

.. autoclass:: fp_sdk.client.FPClient
    :members:

    .. automethod:: __init__
    .. automethod:: _get
    .. automethod:: _post
    .. automethod:: _build_url
    .. automethod:: _delete
    .. automethod:: _scroll