=============
Main Features
=============

* Easy to use tool kit that interacts with Flashpoint Indicators API platform
* Performs authentication to the Flashpoint API platform
* Expressive and intuitive syntax for communicating with the API
* Performs scrolling without need of creating POST requests to the scroll endpoint
* Contains data objects that has built-in JSON support

=====
Usage
=====

Indicators Client Example:

.. code-block:: python
    :emphasize-lines: 1, 4, 9

    from fp_sdk.apis.indicators import IndicatorsClient
    import os

    client = IndicatorsClient(jwt=os.getenv("JWT"))  # Make sure you have your JWT exported
    indicator_result = client.get_event(eventID="Hu2SoTWJWteLrH9mR94JbQ")


    # Gather the results, along with the scroll object to continue scrolling
    event_results, event_pages = client.get_events(scroll=True, limit=2, updated_since='12h')
    for n, page in enumerate(event_pages):
        event_results.extend(page)

        # if we want to break scrolling early, can use clear_scroll() to make sure
        # we dont get "Too many active scroll session errors" in the future
        if n >= 2:
            event_pages.clear_scroll()
            break

    for event in event_results:
        print(f"Event Number: {event_count}")
        print(f"Sources: {event.sources}")

        attribute_count = 1
        # Performs an API call to retrieve JSON of all Attributes, along with transforming them into FPAttribute Data Objects
        event_attributes = event.get_all_attributes()
        for attribute in event_attributes:
            print("Event Number: {} Attribute Number: {}".format(event_count, attribute_count))
            print(f"Sources: {attribute.sources}")
            print(f"Value: {attribute.value}")
            attribute_count += 1

        event_count += 1
        print()

Search Client Example:

.. code-block:: python
    :emphasize-lines: 1, 19, 20, 23

    from fp_sdk.apis.search import SearchClient
    from fp_sdk import basetypes as bt
    import os


    def print_results(results):
        for r in results:
            # using properties for common data points
            print(f"BIN: {r.bin}")
            print(f"Exp: {r.expiration}")
            print(f"Card Type: {r.card_type}")
            print(f"Bank: {r.bank_name}")

            # data objects can also be accessed like dictionaries
            print(f"Cardholder: {r.get('cardholder_information', {}).get('first')}")
            print()


    client = SearchClient(jwt=os.getenv("JWT"))
    results = client.search(basetypes=bt.CARD_DUMP, limit=5)
    print_results(results)

    results = client.search(basetypes=bt.CARD_CVV, limit=5)
    print_results(results)

=======
License
=======
Flashpoint EJ2 Communications
