=======================
Chan Data Documentation
=======================


Chan Data
=========

.. autoclass:: fp_sdk.data.chan.Chan
    :members:
