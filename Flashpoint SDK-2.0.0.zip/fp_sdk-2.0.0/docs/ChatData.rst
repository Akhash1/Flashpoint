=======================
Chat Data Documentation
=======================


Common Chat Data
================

.. autoclass:: fp_sdk.data.chat.ChatCommon
    :members:


Discord Chat Data
=============

.. autoclass:: fp_sdk.data.chat.ChatDiscord
    :members:

Telegram Chat Data
==============

.. autoclass:: fp_sdk.data.chat.ChatTelegram
    :members:

QQ Chat Data
==============

.. autoclass:: fp_sdk.data.chat.ChatQq
    :members: