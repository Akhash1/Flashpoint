=========================
Forum Data Documentation
=========================


Forum Post Data
================

.. autoclass:: fp_sdk.data.forums.ForumPost
    :members:


Forum User Data
=============

.. autoclass:: fp_sdk.data.forums.ForumUser
    :members:

Site Data
==============

.. autoclass:: fp_sdk.data.sites.Site
    :members:
