Search API Client Documentation
===============================

.. autoclass:: fp_sdk.apis.search.SearchClient
    :members: