.. FP_SDK documentation master file, created by
   sphinx-quickstart on Tue Sep 17 12:10:58 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

==============================
Flashpoint SDK's Documentation
==============================

.. toctree::
   :maxdepth: 2
   :caption: Clients:
   
   FPClient
   IndicatorsClient
   SearchClient

.. toctree::
   :maxdepth: 2
   :caption: Data:

   BaseData
   IndicatorsData
   CardData
   ForumData
   ChatData
   ChanData
   PasteData

.. include:: intro.rst 

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
