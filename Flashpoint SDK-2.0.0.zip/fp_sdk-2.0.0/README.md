# fp_sdk

Repository for Flashpoint API Client


## Installation

Install by calling:

`python setup.py install`

## Usage

Detailed documentation can be found [here](https://platform.docs.fpint.net/fp_sdk/).

*Search*

```python
from fp_sdk.apis.search import SearchClient
from fp_sdk import basetypes as bt
import os


def print_results(results):
    for r in results:
        # using properties for common data points
        print(f"BIN: {r.bin}")
        print(f"Exp: {r.expiration}")
        print(f"Card Type: {r.card_type}")
        print(f"Bank: {r.bank_name}")
        # data objects can also be accessed like dictionaries
        print(f"Cardholder: {r.get('cardholder_information', {}).get('first')}")
        print()

client = SearchClient(jwt=os.getenv("JWT"))
results = client.search(basetypes=bt.CARD_DUMP, limit=5)
print_results(results)

results = client.search(basetypes=bt.CARD_CVV, limit=5)
print_results(results)
```

## Implementation Notes

*   If you use `exclude_fields` or `include_fields`, you must receive
    `basetypes` as a response field or you'll get an exception.

## Development

To develop, make sure to install the library in editable mode using a virtual
environment:

```
python3 -m venv venv
source venv/bin/activate
python setup.py develop
pip install -r requirements-dev.txt

# verify install
make test
```
