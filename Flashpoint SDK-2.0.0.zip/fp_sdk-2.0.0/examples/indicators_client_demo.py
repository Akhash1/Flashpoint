from fp_sdk.apis.indicators import IndicatorsClient
import os

client = IndicatorsClient(jwt=os.getenv("JWT"))  # Make sure you have your JWT exported
indicator_result = client.get_event(eventID="Hu2SoTWJWteLrH9mR94JbQ")


# Gather the results, along with the scroll object to continue scrolling
event_results, event_pages = client.get_events(scroll=True, limit=2, updated_since='2d')
for n, page in enumerate(event_pages):
    event_results.extend(page)

    # if we want to break scrolling early, can use clear_scroll() to make sure
    # we dont get "Too many active scroll session errors" in the future
    if n >= 2:
        event_pages.clear_scroll()
        break

# This iterates through all of the events, however there wont be much as the limit is 10000
print(event_results)
event_count = 1

for event in event_results:
    print(f"Event Number: {event_count}")
    print(f"Sources: {event.sources}")

    attribute_count = 1
    # Performs an API call to retrieve JSON of all Attributes, along with transforming them into FPAttribute Data Objects
    event_attributes = event.get_all_attributes()
    for attribute in event_attributes:
        print("Event Number: {} Attribute Number: {}".format(event_count, attribute_count))
        print(f"Sources: {attribute.sources}")
        print(f"Value: {attribute.value}")
        attribute_count += 1

    event_count += 1
    print()
