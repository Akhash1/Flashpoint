from fp_sdk.apis.search import SearchClient
from fp_sdk import basetypes as bt
import os


def print_results(results):
    for res in results:
        print(f"Post from {res.site.title} - {res.site.description}")
        for p in res.get_posts_from_thread(limit=5):
            print(f"{p} \n")
            print(f"Site Actor Handle: {p.site_actor.handle}")
            print(f"Post text: '{p.text}'")
            print(f"Created at: {p.created_at.get('date-time')} \n")


client = SearchClient(jwt=os.getenv("JWT"))
results = client.search(basetypes=bt.FORUM_POST, limit=2)
print_results(results)
