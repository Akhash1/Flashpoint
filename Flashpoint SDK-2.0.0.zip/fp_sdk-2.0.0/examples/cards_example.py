from fp_sdk.apis.search import SearchClient
from fp_sdk import basetypes as bt
import os


def print_results(results):
    for r in results:
        # using properties for common data points
        print(f"BIN: {r.bin}")
        print(f"Exp: {r.expiration}")
        print(f"Card Type: {r.card_type}")
        print(f"Bank: {r.bank_name}")

        # data objects can also be accessed like dictionaries
        print(f"Cardholder: {r.get('cardholder_information', {}).get('first')}")
        print()


client = SearchClient(jwt=os.getenv("JWT"))
results = client.search(basetypes=bt.CARD_DUMP, limit=5)
print_results(results)

results = client.search(basetypes=bt.CARD_CVV, limit=5)
print_results(results)
