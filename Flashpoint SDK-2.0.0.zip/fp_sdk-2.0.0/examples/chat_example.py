from fp_sdk.apis.search import SearchClient
from fp_sdk import basetypes as bt
import os


def print_results(results):
    for r in results:
        # Using properties for common data points
        print(f"Site Title: {r.site.title}")
        print(f"Aliases: {r.aliases}")
        print(f"Handle: {r.handle}")
        print(f"Body: {r.body}")
        print()


client = SearchClient(jwt=os.getenv("JWT"))
chat_telegram_results = client.search(basetypes=bt.TELEGRAM_MESSAGE, limit=10)
print_results(chat_telegram_results)

chat_qq_results = client.search(basetypes=bt.QQ_MESSAGE, limit=10)
print_results(chat_qq_results)

chat_discord_results = client.search(basetypes=bt.DISCORD_MESSAGE, limit=10)
print_results(chat_discord_results)
