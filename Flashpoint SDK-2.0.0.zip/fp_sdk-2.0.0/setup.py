#!/usr/bin/env python
# -*- encoding: utf-8 -*-
import io
from glob import glob
from os.path import basename
from os.path import realpath
from os.path import dirname
from os.path import join
from os.path import splitext

from setuptools import find_packages
from setuptools import setup


def open_config_file(*names, **kwargs):
    current_dir = dirname(realpath(__file__))
    return io.open(
        join(current_dir, *names), encoding=kwargs.get("encoding", "utf8")
    )


install_dependencies = open_config_file("requirements.txt").read().splitlines()

dev_dependencies = open_config_file("requirements-dev.txt").read().splitlines()


setup(
    name="fp_sdk",
    version="2.0.0",
    license="Flashpoint - All rights reserved",
    description="Python clients for Flashpoint APIs",
    long_description="%s\n%s"
    % (
        open_config_file("README.md").read(),
        open_config_file("CHANGELOG.md").read(),
    ),
    author_email="developers@flashpoint-intel.com",
    packages=find_packages("src"),
    package_dir={"": "src"},
    py_modules=[splitext(basename(path))[0] for path in glob("src/*.py")],
    include_package_data=True,
    zip_safe=False,
    classifiers=[
        # complete classifier list:
        # http://pypi.python.org/pypi?%3Aaction=list_classifiers
        "Development Status :: 2 - Pre-Alpha",
        "Intended Audience :: Developers",
        "Operating System :: Unix",
        "Operating System :: POSIX",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: Implementation :: CPython",
    ],
    install_requires=[install_dependencies],
    tests_require=dev_dependencies,
    extras_require={
        "dev": dev_dependencies,
    },
)
